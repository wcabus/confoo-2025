// The contents of this file is from electric's github repo. Modified a bit to fit the needs of our app:
//  https://github.com/electric-sql/electric/blob/bf25e67216855616f0cc3d3da281b66d767ed35a/examples/write-patterns/shared/backend/api.js

import bodyParser from 'body-parser'
import cors from 'cors'
import express from 'express'
import pg from 'pg'
import { z } from 'zod'

// Connect to Postgres.
const DATABASE_URL =
  process.env.DATABASE_URL ||
  'postgresql://postgres:password@localhost:54321/electric'
const pool = new pg.Pool({ connectionString: DATABASE_URL })

// Expose an HTTP server.
const PORT = parseInt(process.env.PORT || '3001')
const app = express()
app.use(bodyParser.json())
app.use(cors())

// Validate user input
const idSchema = z.string().uuid()
const createSchema = z.object({
  id: z.string().uuid(),
  name: z.string(),
  created_at: z.string(),
  write_id: z.string().optional(),
})
const updateSchema = z.object({
  name: z.string(),
  done: z.boolean(),
  write_id: z.string().optional(),
})

// Define functions to create, update and delete todos
// using the `db` client.

const createListItem = async (id, name, created_at, write_id) => {
  const sql = `
    INSERT INTO list_items (id, name, done, created_at, write_id)
    VALUES ($1, $2, false, $3, $4)
  `

  const params = [id, name, created_at, write_id || null]

  await pool.query(sql, params)
}

const updateListItem = async (id, name, done, write_id) => {
  const sql = `
    UPDATE list_items SET name = $2, done = $3, write_id = $4
    WHERE id = $1
  `

  //const params = [done ? '1' : '0', write_id || null, id]
  const params = [id, name, done, write_id || null]

  await pool.query(sql, params)
}

const deleteListItem = async (id) => {
  const sql = 'DELETE from list_items where id = $1'
  const params = [id]
  await pool.query(sql, params)
}

// Expose the shared REST API to create, update and delete todos.

app.post('/list_items', async (req, res) => {
  let data
  try {
    data = createSchema.parse(req.body)
  } catch (err) {
    return res.status(400).json({ errors: err.errors })
  }

  try {
    await createListItem(data.id, data.name, data.created_at, data.write_id)
  } catch (err) {
    return res.status(500).json({ errors: err })
  }

  return res.status(200).json({ status: 'OK' })
})

app.put('/list_items/:id', async (req, res) => {
  let id, data
  try {
    id = idSchema.parse(req.params.id)
    data = updateSchema.parse(req.body)
  } catch (err) {
    return res.status(400).json({ errors: err.errors })
  }

  try {
    await updateListItem(id, data.name, data.done, data.write_id)
  } catch (err) {
    return res.status(500).json({ errors: err })
  }

  return res.status(200).json({ status: 'OK' })
})

app.delete('/list_items/:id', async (req, res) => {
  let id
  try {
    id = idSchema.parse(req.params.id)
  } catch (err) {
    return res.status(400).json({ errors: err.errors })
  }

  try {
    await deleteListItem(id)
  } catch (err) {
    return res.status(500).json({ errors: err })
  }

  return res.status(200).json({ status: 'OK' })
})

// And expose a `POST /changes` route specifically to support the
// through the DB sync pattern.

const transactionsSchema = z.array(
  z.object({
    id: z.string(),
    changes: z.array(
      z.object({
        operation: z.string(),
        value: z.object({
          id: z.string().uuid(),
          name: z.string().optional(),
          done: z.boolean().optional(),
          created_at: z.string().optional(),
        }),
        write_id: z.string(),
      })
    ),
  })
)

app.post('/changes', async (req, res) => {
  let data
  try {
    data = transactionsSchema.parse(req.body)
  } catch (err) {
    return res.status(400).json({ errors: err.errors })
  }

  const client = await pool.connect()
  try {
    await client.query('BEGIN')

    data.forEach((tx) => {
      tx.changes.forEach(({ operation, value, write_id }) => {
        switch (operation) {
          case 'insert':
            createListItem(value.id, value.name, value.created_at, write_id)
            break

          case 'update':
            updateListItem(value.id, value.name, value.done, write_id)
            break

          case 'delete':
            deleteListItem(value.id)
            break
        }
      })
    })

    await client.query('COMMIT')
  } catch (err) {
    await client.query('ROLLBACK')

    return res.status(500).json({ errors: err })
  } finally {
    await client.release()
  }

  return res.status(200).json({ status: 'OK' })
})

// Start the server
app.listen(PORT, () => {
  console.log(`Server listening at port ${PORT}`)
})