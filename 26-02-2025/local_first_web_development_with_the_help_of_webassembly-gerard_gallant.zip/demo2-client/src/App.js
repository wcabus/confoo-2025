import React, { useEffect, useState } from 'react';
import ReactDOM from 'react-dom';
import storage from './sql-pglite'; // our db logic
import ChangeLogSynchronizer from './pg-sync' // the logic to sync changes in our local db to the server
import { PGliteProvider, useLiveQuery, usePGlite } from '@electric-sql/pglite-react'
import RowItem from './RowItem';
import './App.css';

export default function App(){
    let [dbStorage, setDb] = useState(null); // default value for the state object (1st array item) is the parameter in useState (the null), 2nd array item is the function to call to adjust the state object
    let [newItemId, setNewItemId] = useState("");

    useEffect(() => {
        let isMounted = true
        let writePathSync = null;

        async function init() {
            dbStorage = await storage.initDB();

            if (!isMounted) { return; }

            // Start listening for notifications from the changes table
            writePathSync = new ChangeLogSynchronizer(dbStorage)
            writePathSync.start()

            setDb(dbStorage);
        }

        init();

        return () => {
            isMounted = false;

            // Stop listening for notifications from the changes table
            if (writePathSync !== undefined) {
                writePathSync.stop()
            }
        }
    }, []); // empty array so that useEffect only runs once. Otherwise, it runs on every render and we don't need to keep initializing things

    if (dbStorage === null) {
        return <div className="spinner">Loading. Please wait...</div>;
    }
    
    async function handleCreateListItem(db) {
        // Have a new item created in the database
        const res = await storage.createListItem(db);

        // Update the newItemId state so that it gets passed back to the ActualApp function (can't be held as a variable in that function because useLiveQuery
        // will auto update due to the new record being added to the database. Because items changes due to the auto update, the default value of the variable 
        // would be reset). ActualApp passes this value to RowItem so that the row with the matching id will have its textbox given the focus.
        setNewItemId(res.id);

        // Return the record that was created
        return res;
    }

    return (
        // PGliteProvider is needed for useLiveQuery to work (will get a compiler error: 'No PGlite instance found')
        <PGliteProvider db={dbStorage}>
            <ActualApp 
                getListItems={ storage.getListItems }
                onCreateListItem={ handleCreateListItem }
                onUpdateListItemDone={ storage.updateListItemDone }
                onUpdateListItemName={ storage.updateListItemName }
                onDeleteListItem={ storage.deleteListItem }
                newItemID={newItemId}
            />
        </PGliteProvider>
    );
}

function ActualApp(props) {
    const db = usePGlite(); // get a reference to our PGlite object that was passed to PGliteProvider above

    // By using useLiveQuery, the items object is auto updated when changes happen to the table (view in this case). The change could be by us creating/modifying something
    // or by data changing on the server and being adjusted in the database (db.electric.syncShapeToTable in sql-pglite.js is monitoring for changes on the server and adjusts
    // the local database accordingly).
    const items = useLiveQuery("SELECT id,name,done,created_at FROM list_items;"); 
    
    async function onToggleComplete(itemID){
        const index = items.rows.findIndex((ele) => ele.id === itemID);
        if (index !== -1) {
            const isDone = !items.rows[index].done; // toggle
            await props.onUpdateListItemDone(db, itemID, isDone);
        }
    }
    async function onNameChanged(itemID, name) {
        const index = items.rows.findIndex((ele) => ele.id === itemID);
        if (index !== -1) {
            await props.onUpdateListItemName(db, itemID, name);
        }
    }
    async function onDeleteItem(itemID) {
        const index = items.rows.findIndex((ele) => ele.id === itemID);
        if (index !== -1) {
            await props.onDeleteListItem(db, itemID);
        }
    }
    async function onCreateListItem() {
        // Create an empty item in the database
        await props.onCreateListItem(db);
    }

    // If our data isn't ready yet then just show a please wait message...
    if (!items) {
        return <div className="spinner">Loading. Please wait...</div>;
    }

    // Create the individual row components
    const rowItems = items.rows.map((item, index) => (
        <RowItem
            key={item.id}
            id={item.id}
            name={item.name}
            done={item.done} 
            onToggleComplete={(id) => onToggleComplete(id) }
            onNameChanged={(id, name) => onNameChanged(id, name) }
            onDeleteItem={(id) => onDeleteItem(id) }
            newItemId={ props.newItemID }
        />
    ));

    return (
        <div className="container">
            <div className="row mt-3 mb-1">
                PGlite demo with ElectricSQL sync
            </div>
            <div className="row">
                <table className="table table-bordered table-striped table-hover mt-4">
                    <thead className="thead-light">
                        <tr>
                            <th className="width60">Done?</th>
                            <th>Task</th>
                            <th className="width60">Delete</th>
                        </tr>
                    </thead>
                    <tbody id="tbody-list-items">
                        {rowItems}

                        <tr>
                            <td colSpan="3">
                                <input
                                    type="button"
                                    className="btn btn-primary"
                                    value="+ Create new item"
                                    onClick={onCreateListItem}
                                />
                            </td>
                        </tr>                           
                    </tbody>
                </table>
            </div> 
        </div>
    );
}
