// NOTE: I made a few changes but the database structure has been heavily borrowed from ElectricSQL's example:
//    https://electric-sql.com/docs/guides/writes#online-writes
//    https://github.com/electric-sql/electric/blob/main/examples/write-patterns/patterns/4-through-the-db/local-schema.sql

import { PGlite } from '@electric-sql/pglite'
import { live } from '@electric-sql/pglite/live'
import { electricSync } from '@electric-sql/pglite-sync'
import { v4 as uuidv4 } from 'uuid'

async function initDB() {
    // Using IndexedDB for persistence
    const db = await PGlite.create("idb://confoo-demo", {
        extensions: {
            electric: electricSync(),
            live
        }
    });

    // I've removed the 'lists' table that we had in demo1 to simplify things for this demo because there's a fair amount going
    // on with just one table.

    // Create the list_items tables and view
    await db.exec(`
        -- local changes are here (not yet synced to the server)
        CREATE TABLE IF NOT EXISTS list_items_local (
            id UUID PRIMARY KEY,
            name TEXT,
            done BOOLEAN,
            created_at TIMESTAMP WITH TIME ZONE,
            -- bookkeeping 
            changed_columns TEXT[],
            is_deleted BOOLEAN,
            write_id UUID
        );

        -- data that is synced with the server is here
        CREATE TABLE IF NOT EXISTS list_items_synced (
            id UUID PRIMARY KEY,
            name TEXT,
            done BOOLEAN,
            created_at TIMESTAMP WITH TIME ZONE,
            -- bookkeeping 
            write_id UUID
        );

        -- Our Reads/Writes happen here and not on the tables (writes are possible because of an INSTEAD OF trigger that's defined later in this SQL)
        CREATE OR REPLACE VIEW list_items AS
            SELECT
                COALESCE (local.id, synced.id) AS id, -- returns first non-null item in the parameters
                CASE 
                    WHEN 'name' = ANY(local.changed_columns) -- ANY is similar to IN but works on array types
                        THEN local.name -- If the local name changed, use that. otherwise, use the synced name (pattern repeats for the other columns)
                        ELSE synced.name
                    END AS name,
                CASE
                    WHEN 'done' = ANY(local.changed_columns)
                        THEN local.done
                        ELSE synced.done
                    END AS done,
                CASE
                    WHEN 'created_at' = ANY(local.changed_columns)
                        THEN local.created_at
                        ELSE synced.created_at
                    END AS created_at
            FROM list_items_synced AS synced FULL OUTER JOIN list_items_local AS local
                ON synced.id=local.id
            WHERE local.id IS NULL OR local.is_deleted = FALSE; -- local.id will be null if the record is in the synced table but not in the local table. ignore deleted items.
    `);

    // Create a changes table that is given information about inserts, updates, and deletes performed. The data in this table is used for the 
    // data sync with the server
    await db.exec(`
        -- A log of local changes that we want to sync to the server
        CREATE TABLE IF NOT EXISTS changes (
            id BIGSERIAL PRIMARY KEY,
            operation TEXT NOT NULL, -- will hold a value matching the action that led to this record ('insert', 'update', 'delete')
            value JSONB NOT NULL, -- a JSON object with the data that was changed. for a delete, this only holds the id.
            write_id UUID NOT NULL, -- matches the write_id of the local table record
            transaction_id XID8 NOT NULL -- value that will hold the return value from the postgres pg_current_xact_id() function
        );
                
        -- Notify on a 'changes' topic whenever anything is added to the change log
        CREATE OR REPLACE FUNCTION changes_notify_trigger()
        RETURNS TRIGGER AS $$
        BEGIN
            NOTIFY changes;
            RETURN NEW;
        END;
        $$ LANGUAGE plpgsql;
        

        -- When an Insert is called on the changes table, trigger the function above
        CREATE OR REPLACE TRIGGER changes_notify
        AFTER INSERT ON changes
            FOR EACH ROW
            EXECUTE FUNCTION changes_notify_trigger();
    `);

    // Create the INSERT logic
    await db.exec(`
        -- Create a function that will be called when the code tries to 'INSERT INTO' the list_items view (an 'INSTEAD OF' trigger 
        -- will be defined later to trigger this function instead)
        CREATE OR REPLACE FUNCTION list_items_insert_trigger()
        RETURNS TRIGGER AS $$
            DECLARE
                local_created_at TIMESTAMP WITH TIME ZONE := now()::timestamp; -- use the current date/time rather than the caller passing it in
                local_write_id UUID := gen_random_uuid(); -- auto create the write_id column value rather than the caller passing it in
        BEGIN
            -- Just in case someone reuses an existing id, throw an error
            IF EXISTS (SELECT 1 FROM list_items_synced WHERE id=NEW.id) THEN
                RAISE EXCEPTION 'Cannot insert: id already exists in the synced table';
            END IF;
            IF EXISTS (SELECT 1 FROM list_items_local WHERE id=NEW.id) THEN
                RAISE EXCEPTION 'Cannot insert: id already exists in the local table';
            END IF;

            -- Add the data to the local table
            INSERT INTO list_items_local (id,name,done,created_at,changed_columns,is_deleted,write_id)
                VALUES(
                    NEW.id,
                    NEW.name,
                    NEW.done,
                    local_created_at,
                    ARRAY['name','done','created_at'], -- because we're creating a new record, all columns are flagged as changed for this record
                    false,
                    local_write_id
                );

            -- Record the write operation in the change log.
            INSERT INTO changes (operation,value,write_id,transaction_id)
                VALUES (
                    'insert',
                    jsonb_build_object(
                        'id', NEW.id,
                        'name', NEW.name,
                        'done', NEW.done,
                        'created_at', local_created_at
                    ),
                    local_write_id,
                    pg_current_xact_id() -- the transaction's id from Postgres
                );

            RETURN NEW;
        END;
        $$ LANGUAGE plpgsql;


        -- When an Insert is called on the list_items view, send that data to the function we defined above
        CREATE OR REPLACE TRIGGER list_items_insert
        INSTEAD OF INSERT ON list_items
            FOR EACH ROW
            EXECUTE FUNCTION list_items_insert_trigger();
    `);

    // Create the UPDATE logic
    await db.exec(`
        -- Create a function that will be called when the code tries to UPDATE the list_items view (an 'INSTEAD OF' trigger will be defined 
        -- later to trigger this function instead)
        --
        -- NOTE: Because this will be triggered on a view, it appears that specifying an ID that doesn't exist in either table means this
        --       function doesn't get called (good). Passing a bad id does not create a new record.
        --
        CREATE OR REPLACE FUNCTION list_items_update_trigger()
        RETURNS TRIGGER AS $$
            DECLARE
                local record;
                synced record;
                changed_cols TEXT[] := '{}';
                local_created_at TIMESTAMP WITH TIME ZONE := now()::timestamp; -- use the current date/time rather than the caller passing it in
                local_write_id UUID := gen_random_uuid(); -- auto create the write_id column value rather than the caller passing it in
        BEGIN
            -- Grab the synced data (if it exists - might not exist yet if a change was made quickly after the insert or there is a network
            -- connection issue preventing a sync) and the local data (might not exist in this table if the data has been synced and moved
            -- to the synced table)
            SELECT * INTO synced FROM list_items_synced WHERE id = NEW.id; -- being inserted into a 'record' variable delcared above and not creating a table
            SELECT * INTO local FROM list_items_local WHERE id = NEW.id;

            -- The record is not in the local table (FOUND is based on the last statement that was run)
            IF NOT FOUND THEN
                -- Compare each column with the synced table and add to changed_cols if different
                IF NEW.name IS DISTINCT FROM synced.name THEN
                    changed_cols := array_append(changed_cols, 'name');
                END IF;
                IF NEW.done IS DISTINCT FROM synced.done THEN
                    changed_cols := array_append(changed_cols, 'done');
                END IF;
                IF NEW.created_at IS DISTINCT FROM synced.created_at THEN
                    changed_cols := array_append(changed_cols, 'created_at');
                END IF;

                -- Insert a new local record for the changed value
                INSERT INTO list_items_local (id,name,done,created_at,changed_columns,is_deleted,write_id)
                    VALUES (
                        NEW.id,
                        NEW.name,
                        NEW.done,
                        NEW.created_at,
                        changed_cols,
                        FALSE,
                        local_write_id
                    );
            ELSE -- This record is already in the local table...
                UPDATE list_items_local
                SET
                    name = CASE WHEN NEW.name IS DISTINCT FROM synced.name
                            THEN NEW.name
                            ELSE local.name
                        END,
                    done = CASE WHEN NEW.done IS DISTINCT FROM synced.done
                            THEN NEW.done
                            ELSE local.done
                        END,
                    created_at = CASE WHEN NEW.created_at IS DISTINCT FROM synced.created_at
                            THEN NEW.created_at
                            ELSE local.created_at
                        END,
                    -- Set the changed_columns to columes that have both been marked as changed
                    -- and have values that have actually changed.
                    changed_columns = (
                        SELECT array_agg(DISTINCT col) FROM (
                            SELECT unnest(local.changed_columns) AS col -- unnest turns an array into individual rows
                            UNION
                            SELECT unnest(ARRAY['name', 'done', 'created_at']) AS col
                        ) AS cols
                        WHERE (
                            CASE
                            WHEN col = 'name' THEN COALESCE(NEW.name, local.name) IS DISTINCT FROM synced.name
                            WHEN col = 'done' THEN COALESCE(NEW.done, local.done) IS DISTINCT FROM synced.done
                            WHEN col = 'created_at' THEN COALESCE(NEW.created_at, local.created_at) IS DISTINCT FROM synced.created_at
                            END
                        )
                    ),
                    write_id = local_write_id
                WHERE id = NEW.id;
            END IF;
        
            -- Record the update in the change log
            INSERT INTO changes (operation,value,write_id,transaction_id)
                VALUES (
                    'update',
                    jsonb_strip_nulls( -- deletes all object fields  that have null values
                        jsonb_build_object(
                            'id', NEW.id,
                            'name', NEW.name,
                            'done', NEW.done,
                            'created_at', NEW.created_at
                        )
                    ),
                    local_write_id,
                    pg_current_xact_id()
                );

            RETURN NEW;
        END;
        $$ LANGUAGE plpgsql;


        -- When an Update is called on the list_items view, send that data to the function we defined above
        CREATE OR REPLACE TRIGGER list_items_update
        INSTEAD OF UPDATE ON list_items
            FOR EACH ROW
            EXECUTE FUNCTION list_items_update_trigger();
    `);
    
    // Create the DELETE logic
    await db.exec(`
        -- Create a function that will be called when the code calls DELETE on the list_items view (an 'INSTEAD OF' trigger will be defined 
        -- later to trigger this function instead)
        CREATE OR REPLACE FUNCTION list_items_delete_trigger()
        RETURNS TRIGGER AS $$
            DECLARE local_write_id UUID := gen_random_uuid(); -- auto create the write_id column value rather than the caller passing it in
        BEGIN
            -- If the record is currently in the local table (not synced yet)
            IF EXISTS (SELECT 1 FROM list_items_local WHERE id=OLD.id) THEN
                UPDATE list_items_local 
                SET
                    is_deleted=TRUE,
                    write_id=local_write_id
                WHERE id=OLD.id;
            ELSE -- The record isn't in the local table so we need to add it so it gets synced
                INSERT INTO list_items_local (id,is_deleted,write_id)
                    VALUES (
                        OLD.id,
                        TRUE,
                        local_write_id
                    );
            END IF;

            -- Record the delete in the change log
            INSERT INTO changes (operation,value,write_id,transaction_id)
                VALUES (
                    'delete',
                    jsonb_build_object(
                        'id', OLD.id
                    ),
                    local_write_id,
                    pg_current_xact_id()
                );

            RETURN OLD;
        END;
        $$ LANGUAGE plpgsql;


        -- Allow a Delete to be called on the list_items view and redirect those calls to the function above
        CREATE OR REPLACE TRIGGER list_items_delete
        INSTEAD OF DELETE ON list_items
            FOR EACH ROW
            EXECUTE FUNCTION list_items_delete_trigger();
    `);

    // When Items are moved to the sync table, the following trigger removes the record from the local table
    await db.exec(`
        CREATE OR REPLACE FUNCTION delete_local_on_synced_insert_and_update_trigger()
        RETURNS TRIGGER AS $$
        BEGIN
            DELETE FROM list_items_local
                WHERE id = NEW.id
                    AND write_id IS NOT NULL
                    AND write_id = NEW.write_id;

            RETURN NEW;
        END;
        $$ LANGUAGE plpgsql;


        -- When an Insert or Update happens on the sync table, trigger the function above to clean up the local table
        CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
        AFTER INSERT OR UPDATE ON list_items_synced
            FOR EACH ROW
            EXECUTE FUNCTION delete_local_on_synced_insert_and_update_trigger();
    `);
 

    // This monitors the server (docker container in this case) for changes and automatically adjusts our local table accordingly
    //
    // NOTE: Sometimes, if you change something with the shape, you start getting errors with this (in my case "The specified 
    //       shape definition and handle do not match. Please ensure the shape definition is correct or omit the shape handle
    //       from the request to obtain a new one.") but the curl statement worked fine. The electric container has a volume to
    //       remember shape logs. To reset things, run the following and then start the container again:
    //          docker compose down --volumes
    await db.electric.syncShapeToTable({
        shape: {
            url: 'http://localhost:3005/v1/shape',
            params: {
                table: 'list_items'
            }
        },
        shapeKey: 'list_items',
        table: 'list_items_synced',
        primaryKey: ['id']
    });

    return db;
}


async function executeQuery(db, SQL) {
    return await db.query(SQL);
}

async function executeNonQuery(db, SQL) {
    return await db.exec(SQL);
}


export default {
    initDB: initDB,
    async createListItem(db){
        // Create a new record without a value and return it to the caller
        const res = await executeQuery(db, `INSERT INTO list_items (id,name,done) VALUES('${uuidv4()}','',false) RETURNING id,name,done;`);
        return res.rows[0];
    },
    async updateListItemDone(db, itemId, isDone){
        await executeNonQuery(db, `UPDATE list_items SET done=${isDone} WHERE id='${itemId}';`);
    },
    async updateListItemName(db, itemId, updatedName) {
        await executeNonQuery(db, `UPDATE list_items SET name='${updatedName}' WHERE id='${itemId}';`);
    },
    async deleteListItem(db, id) {
        await executeNonQuery(db, `DELETE FROM list_items WHERE id='${id}';`);
    }
}