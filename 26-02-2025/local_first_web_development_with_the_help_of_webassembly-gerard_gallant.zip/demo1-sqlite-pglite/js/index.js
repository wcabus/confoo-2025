let _listId = -1;

async function populateForm(){
    // Because it takes a few seconds to download the wasm files, call back if the database object isn't available yet
    if (typeof itemStorage === "undefined") {
        setTimeout(() => { populateForm(); }, 100);
        return;
    } // End if (typeof itemStorage === "undefined") 

    const listInfo = await itemStorage.getListInfo();
    _listId = listInfo.id;
    document.getElementById("list-name").value = listInfo.name;

    const rows = await itemStorage.getListItems(_listId);
    populateGrid(rows);
}

function populateGrid(dbRows) {
    const tbody = document.getElementById("tbody-list-items");

    const count = dbRows.length;
    for (let i = 0; i < count; i++) {
        createGridRow(tbody, -1, dbRows[i].id, dbRows[i].name, dbRows[i].done); // -1 for the row to be created at the end of the table
    }

    // Create the '+ Create new item' row
    const row = tbody.insertRow();
    const cell = row.insertCell();
    cell.setAttribute("colspan", "3");
    cell.innerHTML = `<input type="button" class="btn btn-primary" value="+ Create new item" onclick="onClickCreateNewItem()" />`;
}

function createGridRow(tbody, insertIndex, itemId, itemName, itemDone) {
    const row = tbody.insertRow(insertIndex);
    row.id = `row-${itemId}`;
    if (itemDone) { row.setAttribute("class", "item-complete"); }

    let cell = row.insertCell(0);
    cell.setAttribute("align", "center");
    cell.setAttribute("class", "align-middle");
    cell.innerHTML = `<input type="checkbox" ${(itemDone ? "checked" : "")} onchange="onChangeRowCheck(${itemId})"/>`;

    cell = row.insertCell(1);
    cell.setAttribute("class", "align-middle");
    cell.innerHTML = `<input id="item-name-${itemId}" type="text" class="focus-edit" value="${itemName}" placeholder="enter a task name" onchange="onChangeRowText(${itemId})" />`;

    cell = row.insertCell(2);
    cell.setAttribute("align", "center");
    cell.innerHTML = `<button class="btn btn-outline-danger btn-delete-row" title="Delete" onclick="onClickDeleteRow(${itemId})"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16"><path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0z"/><path d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4zM2.5 3h11V2h-11z"/></svg></button>`;
}


async function onChangeListName(){ 
    const listName = document.getElementById("list-name");
    await itemStorage.updateListName(_listId, listName.value);
}


async function onChangeRowCheck(itemId) {
    let isTaskDone = false;

    // Grab a reference to the parent's TR element. Toggle the row's CSS class name to indicate if it's
    // complete or not based on it's current state.
    const tr = document.getElementById(`row-${itemId}`);
    if (tr.classList.contains("item-complete")) {
        tr.classList.remove("item-complete");
    } else {
        tr.classList.add("item-complete");
        isTaskDone = true;
    }

    // Save the task's state
    await itemStorage.updateListItemDone(itemId, isTaskDone);
};


async function onChangeRowText(itemId) {
    // Save the task's name
    const itemName = document.getElementById(`item-name-${itemId}`).value;
    await itemStorage.updateListItemName(itemId, itemName);
}


async function onClickDeleteRow(itemId) {
    // Delete the record
    await itemStorage.deleteListItem(itemId);

    // Remove the row from the table
    const tr = document.getElementById(`row-${itemId}`);
    tr.parentElement.removeChild(tr);
}

async function onClickCreateNewItem() {
    // Create a new record without a value and get the new id
    const res = await itemStorage.createListItem(_listId);
    const itemId = res.id;

    // Create the grid row for the new record (palce it before the '+ Create new item' button row) 
    const tbody = document.getElementById("tbody-list-items");
    createGridRow(tbody, (tbody.children.length - 1), itemId, "");

    // Give the new textbox the focus
    document.getElementById(`item-name-${itemId}`).focus();
}