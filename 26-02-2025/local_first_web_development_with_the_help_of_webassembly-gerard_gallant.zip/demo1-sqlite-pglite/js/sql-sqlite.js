// SQL.js docs: https://sql.js.org

const indexedDBName = "/sqlite/confoo-demo"; // PGlite prefixes it with '/pglite/' so using '/sqlite/' so things are similar
const wasmPath = "../sqlite/sql-wasm.wasm";

async function initDB() {
    // Load the database from IndexedDB. If it does not yet exist then...
    let db = await loadDBFromIndexedDB();
    if (db === null) {
        const SQL = await initSqlJs({ locateFile: filename => wasmPath });
        db = new SQL.Database();
        
        // Create the lists table
        await db.run(`
            CREATE TABLE IF NOT EXISTS lists (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT
            );
        `);
        
        // Create a default list record if one doesn't exist yet
        const res = mapResultsToPGliteFormat(await db.exec(`SELECT COUNT(id) AS count FROM lists;`));
        if (parseInt(res.rows[0].count) === 0) {
            await db.run(`INSERT INTO lists (name) VALUES ('Do list for SQLite');`);
        }
        
        // Create the list_items table
        await db.run(`
            CREATE TABLE IF NOT EXISTS list_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                list_id INTEGER,
                name TEXT,
                done BOOLEAN
            );
        `);

        // Persist what we have so far to IndexedDB
        await saveDBToIndexedDB(db);
    } // End if (db === null) 

    return db;
}


const _db = await initDB(); // Execute during file load


// Common function name to use between SQLite and PGlite (.query is used by PGlite and .exec is used by SQLite)
async function executeQuery(db, SQL) {
    // Execute the query
    const res = mapResultsToPGliteFormat(await db.exec(SQL));

    // Just in case the query also made a change to the database, cache the latest version of the database.
    saveDBToIndexedDB(db);

    // Return the response
    return res;
}

async function executeNonQuery(db, SQL) {
    // Execute the query
    const res = await db.run(SQL);

    // Cache the latest version of the database.
    saveDBToIndexedDB(db);

    // Return the response if the caller needs it
    return res;
}

// Convert the data that gets returned from the following format: [{"columns":["Col1"],"values":[[0]]}]
// into the same format as PGlite to make the code easier in index.js. In this case: { "rows": [{ "Col1" : 0 }] }
function mapResultsToPGliteFormat(dbResults) {
    // We'll return an object in the same format as PGlite so the code can be consistent. If there's no
    // data, exit now
    const result = { "rows": [] };
    if (dbResults.length === 0) { return result; }
  
    // Loop through each of the rows in the values array...
    result.rows = dbResults[0].values.map(row => {
        // For the current row, build an object with the column names and the row's values
        return dbResults[0].columns.reduce((obj, column, index) => {
            obj[column] = row[index];
            return obj;
        }, {});
    });
  
    return result;
}


export default {
    async getListInfo(){
        // Get the list info (right now we're only pulling the one item but the idea will be to expand this so someone can have multiple todo lists)
        let res = await executeQuery(_db, `SELECT id,name FROM lists LIMIT 1;`);
        //_listId = res.rows[0].id;
        return res.rows[0];
    },
    async updateListName(listId, updatedName){
        await executeNonQuery(_db, `UPDATE lists SET name='${updatedName}' WHERE id=${listId};`);
    },

    async getListItems(listId){
        // Get the items belonging to the list
        const res = await executeQuery(_db, `SELECT id,name,done FROM list_items WHERE list_id=${listId};`);
        return res.rows;
    },
    async createListItem(listId){
        // Create a new record without a value and return it to the caller
        const res = await executeQuery(_db, `INSERT INTO list_items (list_id,name,done) VALUES(${listId},'',false) RETURNING id,name,done;`);
        return res.rows[0];
    },
    async updateListItemDone(itemId, isDone){
        await executeNonQuery(_db, `UPDATE list_items SET done=${isDone} WHERE id=${itemId};`);
    },
    async updateListItemName(itemId, updatedName) {
        await executeNonQuery(_db, `UPDATE list_items SET name='${updatedName}' WHERE id=${itemId};`);
    },
    async deleteListItem(id) {
        await executeNonQuery(_db, `DELETE FROM list_items WHERE id=${id};`);
    }
}




//------
// More info about working with IndexedDB if you're intersted: https://dzone.com/refcardz/html5-indexeddb
//------
async function loadDBFromIndexedDB() {
    return new Promise((resolve, reject) => {
        // 1 is the db version. If something needs to change with the schema, you'd increment the version. Open the IndexedDB
        // database and then attach to the events.
        const dbRequest = indexedDB.open(indexedDBName, 1);
        dbRequest.onsuccess = (evt) => {
            // Now that we have the indexeddb database open, we need to get the data store. If the store exists then...
            const db = evt.target.result; 
            if (db.objectStoreNames.contains("sqlite")) {
                const store = db.transaction("sqlite").objectStore("sqlite");// transactions are read-only by default
                const getRequest = store.get("dbcontent");
                getRequest.onsuccess = (evt) => {
                    const dbContent = evt.target.result;
                    const SQL = initSqlJs({locateFile: filename => wasmPath});
                    SQL.then((sql) => {
                        const sqlDB = new sql.Database(dbContent);
                        db.close();
                        resolve(sqlDB);
                    });
                }
                getRequest.onerror = (evt) => { 
                    db.close();
                    reject("Error getting the cached data:", evt.target.errorCode); 
                }
            }
            else { // Object store wasn't found (this might be first load and the db hasn't been cached yet)
                // Close the database connnection and then delete the database because opening it created it
                // at version 1. When we go to save the db, it will see that it's already version 1 and won't
                // trigger the onupgradeneeded function.               
                db.close();
                indexedDB.deleteDatabase(indexedDBName);
               
                resolve(null);
            } // End if
        }
        dbRequest.onerror = (evt) => { reject("Error opening IndexedDB:", evt.target.errorCode); }
    });
}

function saveDBToIndexedDB(sqlDB) {
    return new Promise((resolve, reject) => {
        // Get the SQLite db's data as a Unit8Array
        const dbContent = sqlDB.export();

        // 1 is the db version. If something needs to change with the schema, you'd increment the version. Open the IndexedDB
        // database and then attach to the events.
        const dbRequest = indexedDB.open(indexedDBName, 1);

        // If the database version doesn't exist (it won't the first time the view is loaded), this event will be triggered 
        // and this is where you create/update the database structure. The data itself is saved in the onsuccess event.
        dbRequest.onupgradeneeded = (evt) => {
            // If the object store doesn't exist, create it
            const db = evt.target.result; 
            if (!db.objectStoreNames.contains("sqlite")) { db.createObjectStore("sqlite"); }
        }
        
        // Successfully opened the indexedDB
        dbRequest.onsuccess = (evt) => {
            // Get a reference to the object store and then save the SQLite's database info to it
            const db = evt.target.result; 
            const store = db.transaction("sqlite", "readwrite").objectStore("sqlite");
            store.put(dbContent, "dbcontent");

            db.close();
        }

        dbRequest.onerror = (evt) => { reject("Error opening IndexedDB:", evt.target.errorCode); }
    });
}