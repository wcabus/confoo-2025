// PGlite docs: https://pglite.dev/docs/

import { PGlite } from "https://cdn.jsdelivr.net/npm/@electric-sql/pglite/dist/index.js" // PGlite itself

async function initDB() {
    // Using IndexedDB for persistence (leave the constructor empty if you want to create an in-memory database)
    const db = new PGlite("idb://confoo-demo");

    // Create the lists table
    await db.exec(`
        CREATE TABLE IF NOT EXISTS lists (
            id SERIAL PRIMARY KEY,
            name TEXT
        );
    `);

    // Create a default list record if one doesn't exist yet
    let res = await db.query(`SELECT COUNT(id) FROM lists;`);
    if (res.rows[0].count === 0) {
        await db.exec(`INSERT INTO lists (name) VALUES ('Do list for PGlite');`);
    }

    // Create the list_items table
    await db.exec(`
        CREATE TABLE IF NOT EXISTS list_items (
            id SERIAL PRIMARY KEY,
            list_id INTEGER,
            name TEXT,
            done BOOLEAN
        );
    `);

    return db;
}


const _db = await initDB(); // Execute during file load


// Common function name to use between SQLite and PGlite (.query is used by PGlite and .exec is used by SQLite)
async function executeQuery(db, SQL) {
    return await db.query(SQL);
}

async function executeNonQuery(db, SQL) {
    return await db.exec(SQL);
}


export default {
    async getListInfo(){
        // Get the list info (right now we're only pulling the one item but the idea will be to expand this so someone can have multiple todo lists)
        let res = await executeQuery(_db, `SELECT id,name FROM lists LIMIT 1;`);
        return res.rows[0];
    },
    async updateListName(listId, updatedName){
        await executeNonQuery(_db, `UPDATE lists SET name='${updatedName}' WHERE id=${listId};`);
    },

    async getListItems(listId){
        // Get the items belonging to the list
        const res = await executeQuery(_db, `SELECT id,name,done FROM list_items WHERE list_id=${listId};`);
        return res.rows;
    },
    async createListItem(listId){
        // Create a new record without a value and return it to the caller
        const res = await executeQuery(_db, `INSERT INTO list_items (list_id,name,done) VALUES(${listId},'',false) RETURNING id,name,done;`);
        return res.rows[0];
    },
    async updateListItemDone(itemId, isDone){
        await executeNonQuery(_db, `UPDATE list_items SET done=${isDone} WHERE id=${itemId};`);
    },
    async updateListItemName(itemId, updatedName) {
        await executeNonQuery(_db, `UPDATE list_items SET name='${updatedName}' WHERE id=${itemId};`);
    },
    async deleteListItem(id) {
        await executeNonQuery(_db, `DELETE FROM list_items WHERE id=${id};`);
    }
}