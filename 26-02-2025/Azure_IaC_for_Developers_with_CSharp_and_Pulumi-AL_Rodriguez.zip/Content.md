Demo and Full Content: https://github.com/ProgrammerAL/Presentations-2025/tree/main/confoo-2025/azure-iac
