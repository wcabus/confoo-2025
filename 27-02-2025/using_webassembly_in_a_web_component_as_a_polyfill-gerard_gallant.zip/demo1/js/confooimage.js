class ConFooImage extends HTMLElement {
    constructor() {
        super();

        this._shadowRoot = this.attachShadow({mode: "closed"});
        this._shadowRoot.innerHTML = `
            <style>
                :host(confoo-image) {
                    display:flex;
                    justify-content:center;
                    padding: 10px;
                    border:1px solid #ddd;
                    border-radius: 5px;
                    margin-bottom:8px;
                } 

                img {
                    height:600px;
                }
            </style>

            <img src="${this.getAttribute("src")}" alt="${this.getAttribute("alt")}" />
        `;
    }

    // Attributes for this element
    static get observedAttributes() { return ["src", "alt"]; }

    // Exposed properties if accessing this object directly via JS (e.g. document.getElementById("itemID").src = "some new value"; )
    get src() { return this.getAttribute("src"); }
    set src(value) { this.setAttribute("src", value); }

    get alt() { return this.getAttribute("alt"); }
    set alt(value) { this.setAttribute("alt", value); }

    // Allows us to react when an attribute value changes
    attributeChangedCallback(attributeName, oldValue, newValue) {
        // If the value hasn't changed, exit now
        if (oldValue === newValue) { return; }

        console.log(`in ConFooImage... attribute name: ${attributeName}, oldValue: ${oldValue}, newValue: ${newValue}`);
        
        const img = this._shadowRoot.querySelector("img");
        const lowerName = attributeName.toLowerCase();
        if (lowerName === "src") { img.setAttribute("src", newValue); }
        else if (lowerName === "alt") { img.setAttribute("alt", newValue); }
    }
}

customElements.define("confoo-image", ConFooImage);