// This illustrates what's possible but it's not super performant.
// Switching form img.src to canvas renders quicker
// Using a different WebAssembly module might do things differently which might be quicker 
// (e.g. someone mentioned getting decode_oneshot.wasm to do things faster than the 
// current module we're using here)

class ConFooImage extends HTMLElement {
    constructor() {
        super();

        this._isJpegXlSupported = -1; // -1 for we don't know yet, 1 for true, 0 for false
        this._jxlModule = null;
        
        this._shadowRoot = this.attachShadow({mode: "closed"});
        this._shadowRoot.innerHTML = `
            <style>
                :host(confoo-image) {
                    display:flex;
                    justify-content:center;
                    padding: 10px;
                    border:1px solid #ddd;
                    border-radius: 5px;
                    margin-bottom:8px;
                } 

                img {
                    height:600px;
                }
            </style>

            <div>Loading...</div>
            <img src="${this.getAttribute("src")}" alt="${this.getAttribute("alt")}" style="display:none;" />

            <canvas width="500" height="500"></canvas>
        `;

        // Bind to this object so 'this' can access the properites/functions of this object
        this.wasmLoaded = this.wasmLoaded.bind(this);
        this.imageLoaded = this.imageLoaded.bind(this);
    }
  
    // When this element is added to the DOM
    async connectedCallback() {
        // Check to see if the file format is supported...
        try {
            await this.isFormatSupported();
            this._isJpegXlSupported = 1; // Made it here so, yes, supported
        } catch(e) {
            this._isJpegXlSupported = 0; // not supported

            // Load in the WebAssembly logic
            let scriptTag = document.createElement("script");
            scriptTag.src = "js/jxl_decoder.js";
            scriptTag.onload = this.wasmLoaded;
            document.head.appendChild(scriptTag);
        }

        // If the browser supports JPEG XL, just show the image (the browser will handle loading it)
        if (this._isJpegXlSupported) { this.showImage(true, false); }
    }

    isFormatSupported() {
        return new Promise((resolve, reject) => {
            // A 1x1 image
            const img = new Image();
            img.src = "data:image/jxl;base64,/woAkAEB2ABrTgsAgAqVUcYNXs71fPmhw2LaxnWGttq2AAAAAB7AvxLGZnthkJBwBBsXTdwcVHP7gMhQSQI=";
            img.onload = () => { resolve(true); }
            img.onerror = () => { reject("the format is not supported"); }
        });
    }


    // Attributes allowed for this element
    static get observedAttributes() { return ["src", "alt"]; }

    // Exposed properties if accessing this object directly via JS (e.g. document.getElementById("itemID").src = "some new value"; )
    get src() { return this.getAttribute("src"); }
    set src(value) { this.setAttribute("src", value); }

    get alt() { return this.getAttribute("alt"); }
    set alt(value) { this.setAttribute("alt", value); }

    // Called when an attribute value changes
    async attributeChangedCallback(attributeName, oldValue, newValue) {
        // If the value hasn't changed, exit now
        if (oldValue === newValue) { return; }
        const img = this._shadowRoot.querySelector("img");

        // If the src attribute is being modified and the WebAssembly module is ready
        const lowerName = attributeName.toLowerCase();
        if (lowerName === "src") {
            // If the browser supports JPEG XL, let it handle loading the image
            if (this._isJpegXlSupported) { img.setAttribute("src", newValue); }
            else {
                // If the WebAssembly module is ready then handle loading the image
                if (this._jxlModule) { await this.fetchAndDecodeImage(newValue); } 
            }
        } 
        else if (lowerName === "alt") { img.setAttribute("alt", newValue); }
    }

    // The WebAssembly JavaScript has been loaded. This is only called if the file format isn't supported by the browser.
    async wasmLoaded() {
        this._jxlModule = await JxlDecoderModule();

        // If we have a file path then load it in
        if (this.src) { await this.fetchAndDecodeImage(this.src); }         
    }
    
    async fetchAndDecodeImage(src) {
        this.showImage(false, false);
        const response = await fetch(src);
        requestAnimationFrame(() => process(this, this._jxlModule, response));
    } 

    showImage(showImage, showCanvas) {
        const div = this._shadowRoot.querySelector("div");
        const img = this._shadowRoot.querySelector("img");
        const canvas = this._shadowRoot.querySelector("canvas");
        
        if (showImage || showCanvas) {    
            div.style.display = "none"; // Hide loading message

            if (showImage) { img.style.display = ""; }
            else { canvas.style.display = ""; }
        }
        else { // Neither image or canvas are to be shown
            img.style.display = "none";
            canvas.style.display = "none";
            div.style.display = ""; // Show loading message
        }
    }

    renderImage(imageData) {
        const w = imageData.width;
        const h = imageData.height;
    
        // Render to a temporary canvas at the actual size of the image
        const canvas = document.createElement('canvas');
        canvas.width = w;
        canvas.height = h;
        const canvasContext = canvas.getContext('2d');
        canvasContext.putImageData(imageData,0,0); 
    console.log("renderImage... about toBlob");
        canvas.toBlob(blob => {
            const img = this._shadowRoot.querySelector("img");
            img.title = `image size: ${w} x ${h}`;
            img.alt = this.alt;
            img.src = URL.createObjectURL(blob);
            img.onload = this.imageLoaded;
        });
    }

    // This works if you want to draw to a canvas
    renderCanvasImage(imageData) {
        const w = imageData.width;
        const h = imageData.height;

        // Render to a temporary canvas at the actual size of the image
        const canvas = document.createElement('canvas');
        canvas.width = w;
        canvas.height = h;
        const canvasContext = canvas.getContext('2d');
        canvasContext.putImageData(imageData,0,0); 

        // Get a reference to the display canvas and determine the scale the decoded image 
        // needs to use to fit on the canvas (if the image is smaller than the canvas, draw 
        // it at its original size)
        const targetCanvas = this._shadowRoot.querySelector("canvas");
        let scale = Math.min(targetCanvas.width / w, targetCanvas.height / h);
        if (scale > 1.0) { scale = 1; }

        // Display the image
        const context = targetCanvas.getContext("2d");
        context.clearRect(0, 0, 500, 500);
        context.scale(scale, scale);
        context.drawImage(canvas, 0, 0, w, h);
        context.setTransform(1, 0, 0, 1, 0, 0); // reset the scale

        targetCanvas.title = `image size: ${w} x ${h}`;

        this.showImage(false, true);
    }

    imageLoaded() { this.showImage(true, false); }
}

customElements.define("confoo-image", ConFooImage);



async function process(component, jxlModule, fetchResponse) {
    const wantSDR = true;
    let decoder = jxlModule._jxlCreateInstance(/* wantSdr */ wantSDR, /* displayNits */ 100);  // SDR (Standard Dynamic Range) or HDR (High Dynamic Range)
    const bufferSize = 256 * 1024; //256 KB
    let buffer = jxlModule._malloc(bufferSize);
    const reader = fetchResponse.body.getReader();
    readChunk();

    function readChunk() { reader.read().then(onChunk, onError); }

    function onChunk(chunk) {
        if (chunk.done) {
          onFinish();
          return;
        }
        let offset = 0;
        while (offset < chunk.value.length) {
          let delta = chunk.value.length - offset;
          if (delta > bufferSize) {delta = bufferSize; }
          jxlModule.HEAP8.set(chunk.value.slice(offset, offset + delta), buffer);
          offset += delta;
          if (!processChunk(delta)) { onError('Processing error'); }
        }
        setTimeout(readChunk, 0);
    }

    function processChunk(chunkLen) {
        const result = processInput(chunkLen);
        if (result.error) { return false; }
        if (result.wantFlush) { jxlModule._jxlFlush(decoder); }
        if (result.copyPixels) {
            let width = jxlModule.HEAP32[decoder >> 2];
            let height = jxlModule.HEAP32[(decoder + 4) >> 2];
            let pixelData = jxlModule.HEAP32[(decoder + 8) >> 2];

            let src =  null;
            let start = pixelData;
            if (wantSDR) { 
                src = new Uint8Array(jxlModule.HEAP8.buffer); 
            } else {
                src = new Uint16Array(jxlModule.HEAP8.buffer);
                start = start >> 1;
            } 

            let end = start + width * height * 4;
            let imgData = new ImageData(new Uint8ClampedArray(src.slice(start, end)), width, height);
            //requestAnimationFrame(() => component.renderImage(imgData)); // rendering to an img tag
             requestAnimationFrame(() => component.renderCanvasImage(imgData)); // Rendering to a canvas to compare speed
        }
        return true;
    }

    function processInput(chunkLen) {
        const response = { error: false, wantFlush: false, copyPixels: false };
        let result = jxlModule._jxlProcessInput(decoder, buffer, chunkLen);
        if (result === 2) {
            // more data needed (load more of the file)
        } else if (result === 1) {
            response.wantFlush = true;
            response.copyPixels = true;
        }
        else if (result === 0) { // done
            response.wantFlush = false;
            response.copyPixels = true;
        }
        else { response.error = true; }
        return response;
    }

    function onError(data) {
        console.error(data);
        onFinish();
    }

    function onFinish() {
        if (jxlModule) {
          jxlModule._jxlDestroyInstance(decoder);
          jxlModule._free(buffer);
        }
        decoder = buffer = undefined;
    }
}


