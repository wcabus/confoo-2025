class ConfooImageThumb extends HTMLElement {
    constructor() {
        super();

        this._previewElement = document.getElementById(this.getAttribute("preview-element"));

        this._shadowRoot = this.attachShadow({mode: "closed"});
        this._shadowRoot.innerHTML = `
            <style>
                :host(confoo-thumb) {
                    display:inline-block;
                }

                button {
                    border:1px solid #ddd;
                    border-radius:4px;
                    background-color:transparent;
                    padding:5px;
                    margin:0 3px 0 3px;
                    width:150px;
                    overflow:hidden;
                }
                    button:hover { box-shadow:0 0 2px 1px rgba(126, 149, 184, 0.5); }
                
                img {
                    height:150px;
                }
            </style>

            <button type="button">
                <img src="${this.getAttribute("thumb-src")}" alt="${this.getAttribute("alt")}" />
            </button>
        `;
    }

    async connectedCallback() {
        const button = this._shadowRoot.querySelector("button");
        button.addEventListener("click", this.handleClick);

        // If the preview element hasn't yet been initialized, call the handleClick function to set it to the value for
        // this thumbnail.        
        if (!this._previewElement.src) { this.handleClick(); }
    }
    
    
    // Attributes allowed for this element
    static get observedAttributes() { return ["thumb-src", "large-src", "alt", "preview-element"]; }
    
    // Exposed properties if accessing this object directly via JS (e.g. document.getElementById("itemID").thumbSrc = "some new value"; )
    get thumbSrc() { return this.getAttribute("thumb-src"); }
    set thumbSrc(value) { this.setAttribute("thumb-src", value); }

    get largeSrc() { return this.getAttribute("large-src"); }
    set largeSrc(value) { this.setAttribute("large-src", value); }

    get alt() { return this.getAttribute("alt"); }
    set alt(value) { this.setAttribute("alt", value); }

    get previewElement() { return this.getAttribute("preview-element"); }
    set previewElement(value) { this.setAttribute("preview-element", value); }

    // When any of the attributes are adjusted, adjust our element to the latest values
    attributeChangedCallback(attributeName, oldValue, newValue) {
        // If the value hasn't changed, exit now
        if (oldValue === newValue) { return; }

        const img = this._shadowRoot.querySelector("button img");
        const lowerName = attributeName.toLowerCase();
        if (lowerName === "thumb-src") { img.setAttribute("src", newValue); }
        else if (lowerName === "alt") { img.setAttribute("alt", newValue); }
    }

    handleClick = () => {
        const previewElement = document.getElementById(this.getAttribute("preview-element"));
        previewElement.src = this.getAttribute("large-src");
        previewElement.alt = this.getAttribute("alt");
    }
}

customElements.define("confoo-thumb", ConfooImageThumb);