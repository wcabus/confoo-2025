
let jxlModule = null;

async function init(){

    const jpegXLSupported = true;//to not run this code for now


    if (jpegXLSupported) { return; }


    // Only load in the WebAssembly logic if we need it (is there a way to do this dynamically in a web component) 
    const scriptTag = document.createElement("script");
    scriptTag.src = "jxl_decoder.js";
    scriptTag.onload = begin;
    document.head.appendChild(scriptTag); // 
}

async function begin(){
    jxlModule = await JxlDecoderModule();

    const res = await fetch("LG_20181104_135930.jxl");
    requestAnimationFrame(() => process(res));
}


async function process(fetchResponse) {
    const wantSDR = true;
    let decoder = jxlModule._jxlCreateInstance(/* wantSdr */ wantSDR, /* displayNits */ 100);  // SDR (Standard Dynamic Range) or HDR (High Dynamic Range)
    const bufferSize = 256 * 1024;
    let buffer = jxlModule._malloc(bufferSize);
    const reader = fetchResponse.body.getReader();
    readChunk();

    function readChunk() { reader.read().then(onChunk, onError); }

    function onChunk(chunk) {
        if (chunk.done) {
          onFinish();
          return;
        }
        let offset = 0;
        while (offset < chunk.value.length) {
          let delta = chunk.value.length - offset;
          if (delta > bufferSize) {delta = bufferSize; }
          jxlModule.HEAP8.set(chunk.value.slice(offset, offset + delta), buffer);
          offset += delta;
          if (!processChunk(delta)) { onError('Processing error'); }
        }
        setTimeout(readChunk, 0);
    }

    function processChunk(chunkLen) {
        const result = processInput(chunkLen);
        if (result.error) { return false; }
        if (result.wantFlush) { jxlModule._jxlFlush(decoder); }
        if (result.copyPixels) {
          let width = jxlModule.HEAP32[decoder >> 2];
          let height = jxlModule.HEAP32[(decoder + 4) >> 2];
          let pixelData = jxlModule.HEAP32[(decoder + 8) >> 2];

          let src =  null;
          let start = pixelData;
          if (wantSDR) { 
            src = new Uint8Array(jxlModule.HEAP8.buffer); 
        } else {
            src = new Uint16Array(jxlModule.HEAP8.buffer);
            start = start >> 1;
        } 

          let end = start + width * height * 4;
          let imgData = new ImageData(new Uint8ClampedArray(src.slice(start, end)), width, height);
          requestAnimationFrame(() => renderImage(imgData));
        }
        return true;
    }

    function processInput(chunkLen) {
        const response = { error: false, wantFlush: false, copyPixels: false };
        let result = jxlModule._jxlProcessInput(decoder, buffer, chunkLen);
        if (result === 2) {
            // more input needed
        } else if (result === 1) {
            response.wantFlush = true;
            response.copyPixels = true;
        }
        else if (result === 0) { // done
            response.wantFlush = false;
            response.copyPixels = true;
        }
        else { response.error = true; } // error
        return response;
    }

    function onError(data) {
        console.error(data);
        onFinish();
    }

    function onFinish() {
        if (jxlModule) {
          jxlModule._jxlDestroyInstance(decoder);
          jxlModule._free(buffer);
        }
        jxlModule = decoder = buffer = undefined;
    }
  
}


function renderImage(imageData) {
    const w = imageData.width;
    const h = imageData.height;

    // Render to a temporary canvas at the actual size of the image
    const canvas = document.createElement('canvas');
    canvas.width = w;
    canvas.height = h;
    const canvasContext = canvas.getContext('2d');
    canvasContext.putImageData(imageData,0,0); 

    // Get a reference to the display canvas and determine the scale the decoded image 
    // needs to use to fit on the canvas (if the image is smaller than the canvas, draw 
    // it at its original size)
    const targetCanvas = document.getElementById("testCanvas");
    let scale = Math.min(targetCanvas.width / w, targetCanvas.height / h);
    if (scale > 1.0) { scale = 1; }

    // Display the image
    const context = targetCanvas.getContext("2d");
    context.scale(scale, scale);
    context.drawImage(canvas, 0, 0, w, h);

    // Indicate how big the image really was
    document.getElementById("canvasImageSize").innerText = `(actual size: ${w} x ${h})`;
}

